# GitHub ile APK alma - v8 ZIP yöntemi

Tablette klasör yükleme yoksa bu ZIP dosyasını repository'ye tek dosya olarak yükleyebilirsiniz. Repository'ye ayrıca aşağıdaki workflow dosyasını oluşturun:

Dosya adı:

.github/workflows/build-from-zip-v8.yml

İçerik:

```yaml
name: Build APK From v8 ZIP

on:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout repo
        uses: actions/checkout@v4

      - name: Unzip project
        run: |
          unzip IptvStarter_Pro_UIFlow_v8_Cloud_APK_Build.zip -d project
          PROJECT_DIR=$(find project -name "settings.gradle.kts" -exec dirname {} \; | head -1)
          echo "PROJECT_DIR=$PROJECT_DIR" >> $GITHUB_ENV

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - name: Set up Android SDK
        uses: android-actions/setup-android@v3

      - name: Install Android SDK packages
        run: |
          yes | sdkmanager --licenses
          sdkmanager "platforms;android-35" "build-tools;35.0.0" "platform-tools"

      - name: Download Gradle 8.9
        run: |
          curl -L -o gradle-8.9-bin.zip https://services.gradle.org/distributions/gradle-8.9-bin.zip
          unzip -q gradle-8.9-bin.zip
          echo "$PWD/gradle-8.9/bin" >> $GITHUB_PATH

      - name: Build debug APK
        working-directory: ${{ env.PROJECT_DIR }}
        run: gradle --no-daemon :app:assembleDebug

      - name: Upload APK artifact
        uses: actions/upload-artifact@v4
        with:
          name: IPTV-Starter-Pro-v8-debug-apk
          path: ${{ env.PROJECT_DIR }}/app/build/outputs/apk/debug/*.apk
          if-no-files-found: error
```

ZIP dosya adı farklı görünürse workflow içindeki `IptvStarter_Pro_UIFlow_v8_Cloud_APK_Build.zip` adını repository'deki dosya adıyla aynı yapın.
