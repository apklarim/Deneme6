# v10 değişiklikleri

- Tekli playerda son seçilen grup korunur; çift tıkla tekrar açıldığında aynı grubun kanal listesi gelir.
- Grup listesine dönmek için ayrı geri/Gruplar simgeleri eklendi.
- 2'li ve 4'lü oynatmada pencere üzerine çift tıklayınca aynı grup/kanal seçim menüsü açılır.
- Çoklu ekranda seçilen kanal sadece aktif pencereyi değiştirir; diğer pencereler çalışmaya devam eder.
- Gruplara uzun basınca Gizle/Göster ve Adult şifre seçenekleri eklendi.
- Gizli gruplar normal listeden kaldırılır; Gizliler bölümünden tekrar gösterilebilir.
- Adult korumalı grup açılırken PIN sorulur.
- Grup ve kanal panellerine görünür geri simgesi eklendi.
- Odak/gezinme rengi mavi tona çekildi; yazı okunurluğu artırıldı.
