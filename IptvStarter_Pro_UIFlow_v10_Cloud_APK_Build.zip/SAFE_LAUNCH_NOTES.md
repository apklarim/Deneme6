# Safe Launch Fix

Bu paket açılış crashlerini izole etmek için hazırlandı.

Değişiklikler:
- applicationId değiştirildi: com.apklarim.iptvstarter.safe
- Eski uygulama verileriyle çakışmaz.
- Room açılışı UI gösterildikten sonra arka planda ve try/catch içinde yapılır.
- Room 2.6.1 ve Core 1.13.1 gibi daha muhafazakar sürümlere dönüldü.
- Veritabanı adı değiştirildi: iptv_starter_safe_v10.db

Öneri: Cihaza kurmadan önce eski paketleri kaldırın.
