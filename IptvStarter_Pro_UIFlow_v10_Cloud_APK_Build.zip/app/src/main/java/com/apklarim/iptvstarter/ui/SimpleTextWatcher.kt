package com.apklarim.iptvstarter.ui

import android.text.Editable
import android.text.TextWatcher

class SimpleTextWatcher(private val after: () -> Unit) : TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
    override fun afterTextChanged(s: Editable?) = after()
}
